package common.tools;

public class ObjectReader extends AbstractJSONMediaReader {

    public ObjectReader(String aJSONRepresentation) {
        super(aJSONRepresentation);
    }
}
